HOST = "127.0.0.1"
USER = "root"
PASSWD = "root"
company_name = "Lambton College"